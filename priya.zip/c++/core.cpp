#include<bits/stdc++.h>
using namespace std; 
float correl(int X[], int Y[], int n)
{
 
    int sX = 0, sY = 0, sXY = 0;
    int sqX = 0, sqY = 0;
 
    for (int i = 0; i < n; i++)
    {
sX = sX + X[i];
 
        sY = sY + Y[i];
         sXY = sXY + X[i] * Y[i];
 sqX = sqX + X[i] * X[i];
        sqY = sqY + Y[i] * Y[i];
    }
     float corr = (float)(n * sXY - sX * sY) / sqrt((n * sqX - sX * sX) * (n * sqY - sY * sY));
 
    return corr;
}
int main()
{
 
    int X[] = {14, 16, 27, 42, 39,50,83};
    int Y[] = {2, 5, 7, 9, 10,13,20};
    int n = sizeof(X)/sizeof(X[0]);
    cout<<correl(X, Y, n);
    return 0;
}
